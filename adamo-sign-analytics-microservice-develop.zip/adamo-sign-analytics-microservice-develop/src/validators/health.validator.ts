import * as yup from "yup";

export const healthSchema = yup.object().shape({});
