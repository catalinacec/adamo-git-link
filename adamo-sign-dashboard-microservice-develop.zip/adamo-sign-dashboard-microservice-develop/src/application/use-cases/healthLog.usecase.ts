export class HealthUseCase {
  constructor() {}

  async execute(): Promise<any> {
    return true;
  }
}
