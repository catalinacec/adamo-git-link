export interface IDocumentsRepository {}
